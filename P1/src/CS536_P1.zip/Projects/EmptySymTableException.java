package Projects;

public class EmptySymTableException extends Exception{
	public EmptySymTableException(){
		super();
	}
}
