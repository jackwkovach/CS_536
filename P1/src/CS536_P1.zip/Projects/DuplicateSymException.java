package Projects;

public class DuplicateSymException extends Exception{

}
